<?php
$file = "151411513001-1.png"; //Let say If I put the file name Bang.png
echo '<a href='.$file.' target="_blank">download</a>';
?>
